<?php
$_IMC = array();
$_IMC['domain']  	= ''; //Your site domain
$_IMC['apikey']		= ''; //Webim apikey
$_IMC['imsvr']  	= 'ucim.webim20.cn'; 
$_IMC['impost'] 	= '9000'; 
$_IMC['impoll']  	= '8000'; 

$_IMC['version']	= "2.0.0pre";
$_IMC['enable']		= true;//开启webim
$_IMC['show_realname']	= true;//是否显示用户真实姓名。当用户真实姓名不会空时有效
$_IMC['theme']		= 'redmond';//主题
$_IMC['local']		= 'zh-CN'; //[zh-CN,zh-TW,en]
$_IMC['emot']		= 'default';//表情
$_IMC['enable_room']	= false;
$_IMC['room_id_pre']    = 1000000000;

?>
