<?php
echo $time = (string)microtime(true)*1000;
?>
