<?php
$_IMC = array();
$_IMC["enable"] = true;
$_IMC["domain"] = "localhost";
$_IMC["apikey"] = "public";
$_IMC["imsvr"] = "211.144.86.221";
$_IMC["impost"] = 80;
$_IMC["impoll"] = 8000;
$_IMC["theme"] = "redmond";
$_IMC["local"] = "zh-CN";
$_IMC["charset"] = "zh-CN_utf8";
$_IMC["buddy_name"] = "username";
$_IMC["room_id_pre"] = 1000000;
$_IMC["groupchat"] = true;
$_IMC["emot"] = "default";
$_IMC["opacity"] = 80;