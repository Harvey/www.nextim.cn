<div class="clearfix"></div>
<div id="footer">
联系(QQ) · 陈莹: 6168557 徐捷: 1034997251 丫丫: 914223579 · 技术支持(QQ) ·</ br>
© Copyright © 2007-2009 上海几维信息技术有限公司 - KIWI Inc.  苏ICP备10028328
</div>
</div>
