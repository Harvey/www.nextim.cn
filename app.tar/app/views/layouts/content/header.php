<div class="container_12">
<?php include("Logo.php"); ?>
<?php include("NavigationBar.php");?>
</div>