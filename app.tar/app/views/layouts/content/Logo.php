﻿<div class="grid_3 logo">
<a href="/"><img alt="NextIM" src="/img/nextim_global_logo.gif"/>领先的社区网站WEBIM服务供应商</a>
</div>