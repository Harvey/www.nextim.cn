﻿<?php
class AccountsController extends AppController {

	var $name = 'Accounts';
	var $components = Array('Auth', 'Acl');
	var $helpers = array('Html', 'Form');
	
	function beforeFilter(){
		Security::setHash('sha256');
		$this->Auth->userModel = 'Account';
		$this->Auth->fields = array('username'=>'login', 'password'=>'hashed_password');
		$this->Auth->allowedActions = array('register');
		$this->Auth->LoginRedirect = array('controller'=>'account', 'action'=>'view');
	}
	
	function register(){
		if ($this->data){
			if($this->data['Account']['login'] == ''){
				$this->Session->setFlash("请填写邮箱！");
				$this->redirect('/accounts/register');
				exit();
			}
			if(!preg_match('/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/',
						$this->data['Account']['login'])){
				$this->Session->setFlash("请使用合法邮箱地址！");
				$this->redirect('/accounts/register');
				exit();
			}
			if($this->Account->findByLogin($this->data['Account']['login']) > 0){
				$this->Session->setFlash("该邮箱已经注册，请更换一个！");
				$this->redirect('/accounts/register');
				exit();
			}
			if($this->data['Account']['password_confirm'] == ''){
				$this->Session->setFlash("请填写密码！");
				$this->redirect('/accounts/register');
				exit();
			}
			#print_r($this->data);
			if ($this->data['Account']['hashed_password'] == hash('sha256', $this->data['Account']['login'].$this->data['Account']['password_confirm'])){
				$this->Account->create();
				if($this->Account->save($this->data)){
					$this->Auth->login($this->data);
					$parent = $this->Acl->Aro->findByAlias('user');
					$this->Acl->Aro->create(array(
													'alias' => $this->Auth->user('id'),
													'model' => 'Account',
													'foreign_key' => $this->Auth->user('id'),
													'parent_id' => $parent['Aro']['id']
												)
											);
					$this->Acl->Aro->save();
					$parent = $this->Acl->Aco->findByAlias('account');
					$this->Acl->Aco->create(array(
													'alias' => $this->Auth->user('id'),
													'model' => 'Account',
													'foreign_key' => $this->Auth->user('id'),
													'parent_id' => $parent['Aco']['id']
												)
											);
					$this->Acl->Aco->save();
					$this->Acl->allow($this->Auth->user('id'), $this->Auth->user('id'), '*');					
					$this->redirect('/accounts/view');
				}else{
					$this->Session->setFlash("注册时发生错误，请重试！");
					$this->redirect('/accounts/register');
				}
			}else{
				$this->Session->setFlash("两次输入密码不一致，请重试！");
				$this->redirect('/accounts/register');
			}
		}
	}
	
	function login(){
		
	}
	
	function logout(){
		$this->redirect($this->Auth->logout());
	}
	
	function view(){
		$this->Account->recursive = 0;
		$this->set('accounts', $this->paginate('Account', Array('Account.id' => $this->Auth->user('id'))));
	}
	
	function edit(){
		
	}
}
?>